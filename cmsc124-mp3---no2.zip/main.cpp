/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
void expr();
void num();
void digits();
int digit(char x);
void removeSpace();

string INPUT;
int index=0, ERROR=0, decpoint=0;

int main() {
    
     cout<<"Enter input:\t";
     getline(cin, INPUT);
     removeSpace();
     if (INPUT[INPUT.size()-1]!='$') {
        ERROR=1; goto printing;
     }
     expr();
     
     printing:
     if (ERROR==1 || decpoint>1) cout<<"Invalid String\n";
     else cout<<"String accepted\n";
     
     return 0;
}

void expr() {
     if (INPUT[index]=='+' || INPUT[index]=='-') {
         index++;
         num();
     }
     else num();
}

void num() {
     if (INPUT[index]=='.' && digit(INPUT[index-1])==1) {
         decpoint++;
         index++;
         digits();
     }
     else digits();
}

void digits() {
     if (digit(INPUT[index])==1) {
         index++;
         num();
     }
     else if (INPUT[index]=='$' && INPUT[index+1]=='\0' && digit(INPUT[index-1])==1 ) {
        return;
     }
     else { ERROR=1; return; }
}

int digit(char x) {
     if (x>='0' && x<='9') return 1;
     return 0;
}

void removeSpace() {
     char NS_INPUT[20];
     int i=0, j=0;
     while (INPUT[i]!='\0') {
         if (INPUT[i]!=' ') {NS_INPUT[j]=INPUT[i]; j++;}
         i++;
     } NS_INPUT[j] = '\0';
     INPUT = NS_INPUT;
}

