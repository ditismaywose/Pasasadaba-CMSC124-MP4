/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;

void expr();
void expr_ap();
void term();
void term_ap();
void factor();
void digit();
void removeSpace();

string INPUT;
int index=0, ERROR=0, open_par=0, close_par=0;

int main() {
    
    cout<<"Enter string: ";
    getline(cin, INPUT);
    removeSpace();
 
    if (INPUT[INPUT.size()-1]!='$') {
        ERROR=1; goto printing;
    }
 
    expr();
    printing:
 
    if (ERROR==1 || INPUT[INPUT.size()-1]!='$' || open_par!=close_par)
        cout <<"Invalid String\n";
        else cout <<"String Accepted\n";
 
    return 0;
}

void expr() {
     if (INPUT[index]=='+'||INPUT[index]=='-') {
     index++;
     term();
    }
    else term();
}

void term() {
     if (INPUT[index]=='*'||INPUT[index]=='/') {
         index++;
         factor();
     }
     else if (INPUT[index]=='$'&&INPUT[index+1]=='\0') {
         index++;
         return;
     }
    else factor();
}

void factor() {
     if (INPUT[index]=='(' && INPUT[index-1]!=')') {
         open_par++; index++;
         expr();
     }
     else if (INPUT[index]==')' && INPUT[index-1]!='(') {
         close_par++; index++;
         expr();
     }
     else digit();
}

void digit() {
     if (INPUT[index]>='0'&&INPUT[index]<='3' && !isdigit(INPUT[index-1])) {
         index++;
         expr();
     }
     else {
         ERROR=1;
         return;
     }
}

void removeSpace() {
     char NS_INPUT[20];
     int i=0, j=0;
     while (INPUT[i]!='\0') {
     if (INPUT[i]!=' ') {NS_INPUT[j]=INPUT[i]; j++;}
     i++;
     } NS_INPUT[j] = '\0';
     INPUT = NS_INPUT;
}
